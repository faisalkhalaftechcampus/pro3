<?php
use App\Http\Controllers\ReportController;
Route::get('/report/establishments', [ReportController::class, 'generateReport'])->name('report.establishments');
