<?php
namespace App\Http\Controllers;
use Barryvdh\DomPDF\Facade\Pdf;
use App\Models\Establishment;
class ReportController extends Controller {
    public function generateReport() {
        $establishments = Establishment::all();
        $pdf = PDF::loadView('reports.establishments', compact('establishments'))->setPaper('a4', 'landscape');
        return $pdf->download('establishments_report.pdf');
    }
}
