<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>تقرير المنشآت</title>
    <style>
        body { font-family: Arial, sans-serif; direction: rtl; text-align: right; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid black; padding: 10px; text-align: center; }
        th { background-color: #f2f2f2; }
        #map { width: 100%; height: 400px; margin-top: 20px; }
    </style>
</head>
<body>
    <h2>تقرير المنشآت والمخالفات</h2>
    <table>
        <thead>
            <tr>
                <th>رقم المنشأة</th>
                <th>اسم المنشأة</th>
                <th>العنوان</th>
                <th>عدد المخالفات</th>
            </tr>
        </thead>
        <tbody>
            @foreach($establishments as $est)
                <tr>
                    <td>{{ $est->id }}</td>
                    <td>{{ $est->name }}</td>
                    <td>{{ $est->address }}</td>
                    <td>{{ $est->violations->count() }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
    <h3>المواقع الجغرافية للمنشآت</h3>
    <div id="map"></div>
    <script src="https://maps.googleapis.com/maps/api/js?key={{ env('GOOGLE_MAPS_API_KEY') }}"></script>
    <script>
        function initMap() {
            var map = new google.maps.Map(document.getElementById('map'), { center: { lat: 24.7136, lng: 46.6753 }, zoom: 10 });
            var establishments = @json($establishments);
            establishments.forEach(function(est) {
                if (est.latitude && est.longitude) {
                    new google.maps.Marker({ position: { lat: parseFloat(est.latitude), lng: parseFloat(est.longitude) }, map: map, title: est.name });
                }
            });
        }
        window.onload = initMap;
    </script>
</body>
</html>
